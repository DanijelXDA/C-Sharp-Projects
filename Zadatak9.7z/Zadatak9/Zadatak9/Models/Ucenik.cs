﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zadatak9.Models
{
    public class Ucenik
    {
        public int Id { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string Mesto { get; set; }
    }
}