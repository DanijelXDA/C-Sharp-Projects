﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml; // dodati
using System.Xml.Serialization; // dodati
using Zadatak9.Models; // dodati

namespace Zadatak9.Controllers 
{
  public class HomeController: Controller 
  {
       public ActionResult Index() 
       {
        //1. VARIJANTA
        List < Ucenik > ucenici1 = new List < Ucenik > ();
        var putanja = Server.MapPath("~/App_Data/Podaci.xml");
        XmlReader reader = XmlReader.Create(putanja);
        XmlSerializer ser = new XmlSerializer(typeof(List < Ucenik > ), new XmlRootAttribute("Ucenici"));
        ucenici1 = (List < Ucenik > ) ser.Deserialize(reader);


        //2. VARIJANTA
        List < Ucenik > ucenici2 = new List < Ucenik > ();
        XmlDocument dok = new XmlDocument();
        dok.Load(Server.MapPath("~/App_Data/Podaci.xml"));

        foreach(XmlNode node in dok.SelectNodes("/Ucenici/Ucenik")) 
        {
    
         ucenici2.Add(new Ucenik 
         {
               Id = int.Parse(node["Id"].InnerText),
               Ime = node["Ime"].InnerText,
               Prezime = node["Prezime"].InnerText,
               Mesto = node["Mesto"].InnerText
         });

        }

        return View(ucenici1);

       }
    }
}